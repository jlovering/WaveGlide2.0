 
 
 
**********************************************************
*************  Important Instructions Follow  ************
**********************************************************
 
All files exported to: Z:\\52\\81\\5281144\\13\Eagle\2018-03-16_15-40-31\2018-03-16_15-40-31
 
 
**********************************************************
*****************Schematic Instructions  *******************
**********************************************************

To import your new Schematic file into Eagle:

1. Unzip the downloaded folder files to local directory and Start Eagle.
2. Select "File"->"Open"->"Schematic..." from the menu at the top of
the screen.
3. Browse to your newly exported file and select the ".sch" file extension.
4. You should now see your schamtic available in Eagle.

**********************************************************
*******************  PCB Instructions  *******************
**********************************************************

To import your new BOARD file into Eagle:

1. Unzip the downloaded folder files to local directory and Start Eagle.
2. Select "File"->"Open"->"Board..." from the menu at the top of
the screen.
3. Browse to your newly exported file and select the ".brd" file extension.
4. Planes will need to be repoured to update the polygon fills
	1. Once your board is loaded, type "ratsnest" into the command
	   line and press the Enter key.
	2. The polygons should all be filled now.
5. You should now have an image of your board available in Eagle.

**********************************************************
*******************  LIB Instructions  *******************
**********************************************************

To import your new library into Eagle:

1. Start Eagle.
2. Select "File"->"New"->"Library" from the menu.
3. In the blank library window, select "File" -> "Execute Script"
from the menu.
5. Browse to your newly exported Eagle Script file (".scr" file extension)
6. After opening the file, the script will populate the new library.
Layer 93 should NOT exist.
7. Use "File"->Save As: "AcceleratedDesigns_Lib.lbr" and to the desired
location in Eagle native format.
8. Update schematic with the imported library, Select Library and click on Update; open the library file
	and sync. each part.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Eagle_import.html

You may also find this video helpful:
http://youtu.be/5jGuWY-Yy3Q

**********************************************************
**********************************************************
**********************************************************
 
 
Component "GRM033R70J103KA01D" renamed to "GRM033R70J103KA01D"
Component "JMK105BJ225MV-F" renamed to "JMK105BJ225MV-F"
Component "WB_GND" renamed to "WB_GND"
Component "TPS79933DDCR" renamed to "TPS79933DDCR"
Component "WB_BATTERY" renamed to "WB_BATTERY"
Component "WB_CURRENT_LOAD" renamed to "WB_CURRENT_LOAD"
The Symbol WB_CONTINUATION was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CONTINUATION was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CONTINUATION was missing a Value attribute, a value was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_BLOCK_IO was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Type attribute, a type was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Value attribute, a value was created for the symbol.
The Symbol WB_TPS79933 was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_TPS79933 was missing a Type attribute, a type was created for the symbol.
The Symbol WB_TPS79933 was missing a Value attribute, a value was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PWL_VOLTAGE_SOURCE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PWL_VOLTAGE_SOURCE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PWL_VOLTAGE_SOURCE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_SOURCE_RESISTOR was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_SOURCE_RESISTOR was missing a Type attribute, a type was created for the symbol.
The Symbol WB_SOURCE_RESISTOR was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIM_PWL_VOLTAGE_SOURCE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIM_PWL_VOLTAGE_SOURCE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIM_PWL_VOLTAGE_SOURCE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a Type attribute, a type was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIM_STARTUP_VOLTAGE_SOURCE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIM_STARTUP_VOLTAGE_SOURCE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIM_STARTUP_VOLTAGE_SOURCE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_STARTUP_VOLTAGE_SOURCE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_STARTUP_VOLTAGE_SOURCE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_STARTUP_VOLTAGE_SOURCE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PWL_CURRENT_LOAD was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PWL_CURRENT_LOAD was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PWL_CURRENT_LOAD was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIMITIVE_BATTERY was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIMITIVE_BATTERY was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIMITIVE_BATTERY was missing a Value attribute, a value was created for the symbol.
The Symbol WB_TPS799DDC was missing a Value attribute, a value was created for the symbol.


Ultra Librarian Gold 8.1.204 Process Report


Message - Padstack "RX14Y13D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX22Y24D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX49p65Y21p69D0T" Shape(4) is a CIRCLE with no diameter.
Message - Component "GRM033R70J103KA01D" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM033R70J103KA01D" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM033R70J103KA01D" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM033R70J103KA01D" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "JMK105BJ225MV-F" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "JMK105BJ225MV-F" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "JMK105BJ225MV-F" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "JMK105BJ225MV-F" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "JMK105BJ225MV-F" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS79933DDCR" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS79933DDCR" attribute "Frequency" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS79933DDCR" attribute "Imax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS79933DDCR" attribute "Package" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS79933DDCR" attribute "Mktg_Package" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS79933DDCR" attribute "NSID" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.

TextStyle count:  24
Padstack count:   3
Pattern count:    3
Symbol count:     18
Component count:  6

Export

Component "WB_GND" has no mapped footprint will be skipped.
Component "WB_BATTERY" has no mapped footprint will be skipped.
Component "WB_CURRENT_LOAD" has no mapped footprint will be skipped.
