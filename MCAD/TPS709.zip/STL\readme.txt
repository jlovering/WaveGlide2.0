 
 
 
**********************************************************
*************  Important Instructions Follow  ************
**********************************************************
 
All files exported to: C:\EMA\ExportFolder\0\175345\Output\STL\STL
 
 
To import your new 3D models follow these steps:

Select your view and open it.
File load the STL file located at the address above.

We use and recommend using the free reader from http://www.stpviewer.com/

Or for color renderings use http://www.freecad.com/

For additional information, please visit this site:
http://www.accelerated-designs.com/help/STL.html

To see a video tutorial of this process, please visit:
http://youtu.be/eTT0_6xa0so
 
 
